package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@SpringBootApplication
public class SpringLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(SpringLearnApplication.class, args);
		SpringLearnApplication spa = new SpringLearnApplication();
		spa.displayDate();
		spa.displayCountry();
		spa.displayCountries();
		
	}

	public void displayDate() {
		
		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
		SimpleDateFormat format = (SimpleDateFormat)context.getBean("dateFormat");

		Date date = null;
		try {
			date = format.parse("31/12/2018");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.debug(date.toString());
		
		LOGGER.info("END");
		
	}
	public void displayCountry() {
		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("country");
		Country anotherCountry = context.getBean("country",Country.class);
		LOGGER.debug("Country : {}",country.toString());
		LOGGER.debug("AnotherCountry : {}",anotherCountry.toString());
		LOGGER.info("END");
	}
	
	public void displayCountries() {
		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries =  (List<Country>) context.getBean("countryList");
		LOGGER.debug("CountryList : {}",countries);
		LOGGER.info("END");
	}
}
