package com.cognizant.springlearnhandson4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnHandson4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
