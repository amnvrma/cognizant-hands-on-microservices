package com.cognizant.springlearnhandson4;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SpringLearnHandson4Application {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnHandson4Application.class);

	public static void displayDate() {
		LOGGER.info("START");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("date-format.xml");
		SimpleDateFormat fmt = ctx.getBean("dateFormat", SimpleDateFormat.class);
		try {
			Date date = fmt.parse("31/12/2018");
			LOGGER.debug(date.toString());
		} catch (Exception e) {
			System.out.println(e);
		}
		LOGGER.info("END");
	}

	public static void displayCountry() {
		LOGGER.info("START");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		Country country = ctx.getBean("country", Country.class);
		Country anotherCountry = ctx.getBean("country", Country.class);
		LOGGER.debug("Country : {}", country.toString());
		LOGGER.debug("AnotherCountry : {}", anotherCountry.toString());
		LOGGER.info("END");
	}

	public static void displayCountries() {
		LOGGER.info("START");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		List<Country> list = (List<Country>) ctx.getBean("countryList");
		LOGGER.debug("CountryList : {}", list.toString());
		LOGGER.info("END");
	}

	public static void main(String[] args) {

		SpringApplication.run(SpringLearnHandson4Application.class, args);
		displayDate();
		displayCountry();
		displayCountries();
	}

}
