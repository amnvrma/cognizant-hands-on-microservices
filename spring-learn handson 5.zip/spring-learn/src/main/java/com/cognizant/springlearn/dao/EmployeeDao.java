package com.cognizant.springlearn.dao;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.model.Employee;
@Component
public class EmployeeDao {
	public static ArrayList<Employee> EMPLOYEE_LIST;
	public EmployeeDao() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		EMPLOYEE_LIST = (ArrayList<Employee>)ctx.getBean("employeeList");
	}
	public ArrayList<Employee> getAllEmployees() {
		return EMPLOYEE_LIST;
	}
	
	public static Employee getEmployee(int id) {
		for(Employee emp:EMPLOYEE_LIST) {
			if(Integer.parseInt(emp.getId()) == id) return  emp;
		}
		return null;
	}
}
