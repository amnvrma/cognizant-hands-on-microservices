package com.cognizant.springlearn;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.cognizant.springlearn.dao.EmployeeDao;
import com.cognizant.springlearn.model.Employee;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedMethods("GET").allowedOrigins("http://localhost:4200");
		
//		All origins
//		registry.addMapping("/**").allowedMethods("*").allowedOrigins("*");
	}
	
	public Employee getEmployee(int id) {
		return EmployeeDao.getEmployee(id);
	}

}
