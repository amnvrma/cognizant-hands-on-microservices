package com.cognizant.springlearn.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.dao.EmployeeDao;

@Component("employeeService")
public class EmployeeService {
	@Autowired
	EmployeeDao employeeDao;
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);

	public EmployeeService() {
		LOGGER.info("Inside EmployeeService");
	}

	
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
}