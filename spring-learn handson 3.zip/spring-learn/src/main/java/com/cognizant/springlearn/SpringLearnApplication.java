package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.controller.EmployeeController;

@ComponentScan("com.cognizant.springlearn")
@SpringBootApplication
public class SpringLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SpringLearnApplication.class, args);
		SpringLearnApplication.displayDate();
		SpringLearnApplication.displayCountry();
		SpringLearnApplication.displayCountries();
		SpringLearnApplication.displayEmployee();
//		SpringLearnApplication.getEmployeeController();
		SpringLearnApplication.displayEmployeeControllerAnnotation(new ClassPathXmlApplicationContext("employee.xml"));

	}

	public static void displayDate() {

		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
		SimpleDateFormat format = (SimpleDateFormat) context.getBean("dateFormat");

		Date date = null;
		try {
			date = format.parse("31/12/2018");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.debug(date.toString());

		LOGGER.info("END");

	}

	public static void displayCountry() {
		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("country");
		Country anotherCountry = context.getBean("country", Country.class);
		LOGGER.debug("Country : {}", country.toString());
		LOGGER.debug("AnotherCountry : {}", anotherCountry.toString());
		LOGGER.info("END");
	}

	public static void displayCountries() {
		LOGGER.info("START");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		List<Country> countries = (List<Country>) context.getBean("countryList");
		LOGGER.debug("CountryList : {}", countries);
		System.out.println(countries);
		LOGGER.info("END");
	}

	public static void displayEmployee() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		Employee employee = (Employee) context.getBean("emp");
		LOGGER.debug("Employee details: {}", employee);
	}

	public static void getEmployeeController() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		EmployeeController employeeController = (EmployeeController) context.getBean("employeeController-autowired");

	}

	public static void displayEmployeeControllerAnnotation(ApplicationContext applicationContext) {
		EmployeeController employeeController = (EmployeeController) applicationContext.getBean("employeeController");
	
	}
}
