package com.cognizant.springlearn.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.service.AppUserService;

@RestController
public class AuthenticationController {

	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtTokenUtil jwtTokenUtil;
	@Autowired
	AppUserService userService;

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

	@PostMapping("/authenticate")
	public ResponseEntity<Map<String, String>> authenticate(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		LOGGER.info("START");
		HashMap<String, String> map = new HashMap<>();
//		 LOGGER.debug(authHeader);
//		 String user = getUser(authHeader);
//		 LOGGER.debug(user);
//		 String jwt = generateJwt(user);
//		 map.put("token", jwt);
//		 LOGGER.debug(jwt);
//		 LOGGER.info("END");

		try {
	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password);
	        Authentication authentication = authenticationManager.authenticate(token);
	        UserDetails userDetails = userService.loadUserByUsername(username);
	        String jwtToken = jwtTokenUtil.generateToken(userDetails);
	        
	        Map<String, String> tokenMap = new HashMap<>();
	        tokenMap.put("token", jwtToken);
	        
	        return ResponseEntity.ok(tokenMap);
	    } catch (Exception ex){
	    	  return ResponseEntity.ok(null);
	    }

	}

//	private String getUser(String authHeader) {
//		String encodedCredentials = authHeader.split(" ")[1];
//		byte[] decodedBytes = Base64.getDecoder().decode(encodedCredentials);
//		String decodedCredentials = new String(decodedBytes);
//		 LOGGER.debug(decodedCredentials);
//		 String user = decodedCredentials.split(":")[0];
//		 return user;
//	}

//	private String generateJwt(String user) {
//		JwtBuilder builder = Jwts.builder();
//        builder.setSubject(user);
//
//        // Set the token issue time as current time
//        builder.setIssuedAt(new Date());
//
//        // Set the token expiry as 20 minutes from now
//        builder.setExpiration(new Date((new Date()).getTime() + 1200000));
//        builder.signWith(SignatureAlgorithm.HS256, "secretkey");
//
//        String token = builder.compact();
//
//        return token;
//
//	}
}
